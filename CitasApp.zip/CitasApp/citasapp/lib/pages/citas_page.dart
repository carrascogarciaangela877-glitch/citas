import 'package:flutter/material.dart';
import '../models/cita.dart';
import 'formulario_cita_page.dart';

class CitasPage extends StatefulWidget {
  const CitasPage({super.key});

  @override
  State<CitasPage> createState() => _CitasPageState();
}

class _CitasPageState extends State<CitasPage> {
  final List<Cita> citas = [];

  Future<void> abrirFormulario() async {
    final Cita? nuevaCita = await Navigator.push<Cita>(
      context,
      MaterialPageRoute(
        builder: (context) => const FormularioCitaPage(),
      ),
    );

    if (nuevaCita != null) {
      setState(() {
        citas.add(nuevaCita);
      });
    }
  }

  String formatoFecha(DateTime fecha) {
    return '${fecha.day.toString().padLeft(2, '0')}/'
        '${fecha.month.toString().padLeft(2, '0')}/'
        '${fecha.year}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('CitasApp'),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: Center(
              child: Badge(
                label: Text(citas.length.toString()),
                child: const Icon(Icons.calendar_month),
              ),
            ),
          ),
        ],
      ),

      body: citas.isEmpty
          ? const Center(
              child: Text(
                'No hay citas registradas',
                style: TextStyle(fontSize: 18),
              ),
            )
          : SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: SingleChildScrollView(
                child: DataTable(
                  columns: const [
                    DataColumn(label: Text('DNI')),
                    DataColumn(label: Text('Paciente')),
                    DataColumn(label: Text('Especialidad')),
                    DataColumn(label: Text('Seguro')),
                    DataColumn(label: Text('Fecha')),
                    DataColumn(label: Text('Hora')),
                  ],
                  rows: citas.map((cita) {
                    return DataRow(
                      cells: [
                        DataCell(Text(cita.dni)),
                        DataCell(Text(cita.paciente)),
                        DataCell(Text(cita.especialidad)),
                        DataCell(Text(cita.tipoSeguro)),
                        DataCell(Text(formatoFecha(cita.fecha))),
                        DataCell(Text(cita.hora)),
                      ],
                    );
                  }).toList(),
                ),
              ),
            ),

      floatingActionButton: FloatingActionButton.extended(
        onPressed: abrirFormulario,
        icon: const Icon(Icons.add),
        label: const Text('Registrar cita'),
      ),
    );
  }
}