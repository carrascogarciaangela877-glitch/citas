import 'package:flutter/material.dart';
import '../models/cita.dart';

class FormularioCitaPage extends StatefulWidget {
  const FormularioCitaPage({super.key});

  @override
  State<FormularioCitaPage> createState() => _FormularioCitaPageState();
}

class _FormularioCitaPageState extends State<FormularioCitaPage> {
  final _formKey = GlobalKey<FormState>();

  final TextEditingController dniController = TextEditingController();
  final TextEditingController pacienteController = TextEditingController();
  final TextEditingController telefonoController = TextEditingController();

  String? especialidad;
  String tipoSeguro = 'SIS';

  DateTime? fecha;
  TimeOfDay? hora;

  double urgencia = 1;
  bool primeraConsulta = false;

  final List<String> especialidades = [
    'Medicina General',
    'Pediatría',
    'Cardiología',
    'Odontología',
    'Dermatología',
    'Otro',
  ];

  Future<void> seleccionarFecha() async {
    final DateTime hoy = DateTime.now();

    final DateTime? seleccion = await showDatePicker(
      context: context,
      initialDate: hoy,
      firstDate: hoy,
      lastDate: DateTime(2030),
    );

    if (seleccion != null) {
      setState(() {
        fecha = seleccion;
      });
    }
  }

  Future<void> seleccionarHora() async {
    final TimeOfDay? seleccion = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );

    if (seleccion != null) {
      setState(() {
        hora = seleccion;
      });
    }
  }

  void registrarCita() {
    if (!_formKey.currentState!.validate()) {
      return;
    }

    if (especialidad == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Seleccione una especialidad'),
        ),
      );
      return;
    }

    if (fecha == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Seleccione la fecha de la cita'),
        ),
      );
      return;
    }

    if (hora == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Seleccione la hora de la cita'),
        ),
      );
      return;
    }

    final cita = Cita(
      dni: dniController.text,
      paciente: pacienteController.text,
      telefono: telefonoController.text,
      especialidad: especialidad!,
      tipoSeguro: tipoSeguro,
      fecha: fecha!,
      hora: hora!.format(context),
      urgencia: urgencia.toInt(),
      primeraConsulta: primeraConsulta,
    );

    Navigator.pop(context, cita);
  }

  @override
  void dispose() {
    dniController.dispose();
    pacienteController.dispose();
    telefonoController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Registrar cita'),
      ),
      body: Form(
        key: _formKey,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextFormField(
                controller: dniController,
                keyboardType: TextInputType.number,
                maxLength: 8,
                decoration: const InputDecoration(
                  labelText: 'DNI del paciente',
                  border: OutlineInputBorder(),
                  counterText: '',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'El DNI es obligatorio';
                  }

                  if (!RegExp(r'^\d{8}$').hasMatch(value)) {
                    return 'El DNI debe tener exactamente 8 dígitos';
                  }

                  return null;
                },
              ),

              const SizedBox(height: 15),

              TextFormField(
                controller: pacienteController,
                decoration: const InputDecoration(
                  labelText: 'Nombres y apellidos',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'El nombre es obligatorio';
                  }

                  if (!RegExp(r'^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$')
                      .hasMatch(value.trim())) {
                    return 'Solo se permiten letras y espacios';
                  }

                  return null;
                },
              ),

              const SizedBox(height: 15),

              TextFormField(
                controller: telefonoController,
                keyboardType: TextInputType.phone,
                maxLength: 9,
                decoration: const InputDecoration(
                  labelText: 'Teléfono',
                  border: OutlineInputBorder(),
                  counterText: '',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'El teléfono es obligatorio';
                  }

                  if (!RegExp(r'^\d{9}$').hasMatch(value)) {
                    return 'Debe tener exactamente 9 dígitos';
                  }

                  return null;
                },
              ),

              const SizedBox(height: 15),

              DropdownButtonFormField<String>(
                value: especialidad,
                decoration: const InputDecoration(
                  labelText: 'Especialidad',
                  border: OutlineInputBorder(),
                ),
                items: especialidades.map((especialidad) {
                  return DropdownMenuItem(
                    value: especialidad,
                    child: Text(especialidad),
                  );
                }).toList(),
                onChanged: (value) {
                  setState(() {
                    especialidad = value;
                  });
                },
              ),

              const SizedBox(height: 20),

              const Text(
                'Tipo de seguro',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),

              const SizedBox(height: 8),

              SegmentedButton<String>(
                segments: const [
                  ButtonSegment(
                    value: 'SIS',
                    label: Text('SIS'),
                  ),
                  ButtonSegment(
                    value: 'EsSalud',
                    label: Text('EsSalud'),
                  ),
                  ButtonSegment(
                    value: 'Particular',
                    label: Text('Particular'),
                  ),
                ],
                selected: {tipoSeguro},
                onSelectionChanged: (seleccion) {
                  setState(() {
                    tipoSeguro = seleccion.first;
                  });
                },
              ),

              const SizedBox(height: 20),

              const Text(
                'Fecha de la cita',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 8),

              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: seleccionarFecha,
                  icon: const Icon(Icons.calendar_month),
                  label: Text(
                    fecha == null
                        ? 'Seleccionar fecha'
                        : '${fecha!.day}/${fecha!.month}/${fecha!.year}',
                  ),
                ),
              ),

              const SizedBox(height: 15),

              const Text(
                'Hora de la cita',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 8),

              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: seleccionarHora,
                  icon: const Icon(Icons.access_time),
                  label: Text(
                    hora == null
                        ? 'Seleccionar hora'
                        : hora!.format(context),
                  ),
                ),
              ),

              const SizedBox(height: 20),

              Text(
                'Nivel de urgencia: ${urgencia.toInt()}',
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                ),
              ),

              Slider(
                value: urgencia,
                min: 1,
                max: 5,
                divisions: 4,
                label: urgencia.toInt().toString(),
                onChanged: (value) {
                  setState(() {
                    urgencia = value;
                  });
                },
              ),

              SwitchListTile(
                title: const Text('¿Primera consulta?'),
                value: primeraConsulta,
                onChanged: (value) {
                  setState(() {
                    primeraConsulta = value;
                  });
                },
              ),

              const SizedBox(height: 20),

              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton.icon(
                  onPressed: registrarCita,
                  icon: const Icon(Icons.save),
                  label: const Text(
                    'Registrar cita',
                    style: TextStyle(fontSize: 16),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}