class Cita {
  final String dni;
  final String paciente;
  final String telefono;
  final String especialidad;
  final String tipoSeguro;
  final DateTime fecha;
  final String hora;
  final int urgencia;
  final bool primeraConsulta;

  const Cita({
    required this.dni,
    required this.paciente,
    required this.telefono,
    required this.especialidad,
    required this.tipoSeguro,
    required this.fecha,
    required this.hora,
    required this.urgencia,
    required this.primeraConsulta,
  });
}