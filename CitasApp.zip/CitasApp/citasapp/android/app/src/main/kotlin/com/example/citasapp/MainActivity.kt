package com.example.citasapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
